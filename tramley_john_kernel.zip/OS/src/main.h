#ifndef MAIN_H
#define MAIN_H

struct multiboot
{
};

#endif

